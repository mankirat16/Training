import React from "react";
export default function ProfilePic() {
  return <div></div>;
}
