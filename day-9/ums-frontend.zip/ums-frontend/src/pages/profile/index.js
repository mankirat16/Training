import Info from "./userInfo";

export default function User() {
  return (
    <div>
      <Info />
    </div>
  );
}
